import pytest
import respx
import httpx
from httpx import Response
import json


@pytest.mark.asyncio  # <--- ACEASTA ESTE LINIA MAGICĂ
@respx.mock
async def test_send_results_to_java_success():
    # 1. ARRANGE
    target_url = "https://java-server.com/api/callback"
    mock_data = {"status": "completed", "score": 80}

    route = respx.post(target_url).mock(return_value=Response(200))

    # 2. ACT
    async with httpx.AsyncClient() as client:
        response = await client.post(target_url, json=mock_data)

    # 3. ASSERT
    assert response.status_code == 200
    assert route.called
    sent_data = json.loads(route.calls.last.request.content)
    assert sent_data == mock_data
