import pytest
import json
from fastapi.testclient import TestClient
from unittest.mock import patch
from ai_service.main import app

client = TestClient(app)


@patch("ai_service.api.endpoints.generate_pop_quiz")
def test_pop_quiz_endpoint_success(mock_ai):
    mock_ai.return_value = '{"questions": []}'

    payload = {
        "lesson_type": "Science",
        "lesson_text": "Test content",
        "difficulty": "easy"
    }

    response = client.post("/get-pop-quiz", json=payload)

    assert response.status_code == 200
    mock_ai.assert_called_once()


def test_pop_quiz_endpoint_respinge_date_invalide():
    payload_invalid = {
        "lesson_type": "Science"
    }

    response = client.post("/get-pop-quiz", json=payload_invalid)

    assert response.status_code == 422


@patch("ai_service.api.endpoints.generate_final_mcq_test")
def test_get_final_test_success(mock_ai):
    mock_questions = [
        {"id": i, "question": f"Q{i}", "options": ["A", "B"], "num_correct": 1}
        for i in range(1, 11)
    ]
    mock_ai.return_value = json.dumps(mock_questions)

    payload = {
        "topic_name": "Python Arrays",
        "lesson_text": "Arrays are used to store multiple values...",
        "difficulty": "medium"
    }

    # 2. ACT
    response = client.post("/get-final-test", json=payload)

    # 3. ASSERT
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 10  # Verificăm cerința ta critică de 10 întrebări
    assert data[0]["id"] == 1
